Description
===========

In this work we aim at providing an effective support for reasoning about imperative programs with data structures and aliasing, by extending the expressiveness of more familiar type-based verification towards more informative logical reasoning, without compromising soundness and completeness.

Currently is hard to reason about global and shape properties of data structures. Existing tools require too much effort, a lot of experience from the user and rely on mechanisms that don't scale.

We develop an assertion language that is closer to a programming language, that we call, functional assertion language, which is easier to use for programmers, and amenable to automatic verification.

This prototype checks that programs comply to their specification, that is, if we satisfy the pre-condition of a program, after the execution of the program we ensure that the post-condition holds.

Downloads
=========

[Packaged Version](http://ctp.di.fct.unl.pt/~tsantos/tools/improve.tar.gz)

You can try our tool online [here](http://ctp.di.fct.unl.pt/~tsantos/funspec/improve)

Installation
============

1. Download the packaged version above

2. Unpack the tar.gz file

3. Execute the improve script following the instructions below

Usage
=====

```
ImProVe [version 0.2.0]. (C) Copyright 2015
Usage: sh improve [OPTION]...

Options:

  -a, --api                Force smt api usage

  -d, --debug  <mode>      Debug mode (default = NONE)

  -r, --fileInteractive    File interactive mode

  -f, --files  <file>...   Input file list

  -i, --interactive        Interactive mode

  -o, --output  <file>     Redirect program output to a file

  -p, --process            Force smt process usage

  -v, --shortVersion       Version number

  -s, --stdin              Read from standard input

  -t, --test               Test mode

      --help               Show help message

      --version            Show version of this program
```

Notes
-----

For option `-f, --files`, if `<file>` is a directory all files with extension
`.imp` in the directory `<file>` are executed

By default if you don't provide arguments the program will execute in interactive mode

An ImProVe program is composed by a sequence (possibly empty) of type definitions,
predicate definitions or triples (pre-condition, imperative program and post-condition)

Quick Example
=============

```
x:ref int

{ let a = !x in a > 0 } x := -3 { let b = !x in b < 0 }

;;
```